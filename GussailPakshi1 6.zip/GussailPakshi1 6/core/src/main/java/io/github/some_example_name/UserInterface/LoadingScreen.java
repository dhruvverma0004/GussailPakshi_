package io.github.some_example_name.UserInterface;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class LoadingScreen extends ScreenAdapter {
    private Game game;
    private SpriteBatch batch;
    private Texture loadingImage;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Stage stage;
    private ImageButton newGameButton, loadGameButton, exitButton, settingsButton;
    private Texture newGameTex, loadGameTex, exitTex, settingsButtonTex; // Textures for buttons

    // Defining Constructor to initialize essential objects
    public LoadingScreen(Game game) {
        this.game = game;
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
        viewport = new FitViewport(1920, 1080, camera);
        stage = new Stage(viewport, batch);
    }

    @Override
    public void show() {
        // Set the input processor to stage to capture UI interactions
        Gdx.input.setInputProcessor(stage);

        // Loading he background and button textures
        loadingImage = new Texture("loadingscreen.png");
        settingsButtonTex = new Texture("settingsButton.png");

        // Initializing and positioning buttons
        setupButtons();
        setupSettingsButton();

        // Add all buttons to the stage for rendering and interaction
        stage.addActor(newGameButton);
        stage.addActor(loadGameButton);
        stage.addActor(exitButton);
        stage.addActor(settingsButton);
    }

    // Method to set up main menu buttons and their functionalities
    private void setupButtons() {
        newGameTex = new Texture("newgame.png");
        loadGameTex = new Texture("loadgame.png");
        exitTex = new Texture("exit.png");

        newGameButton = new ImageButton(new TextureRegionDrawable(newGameTex));
        loadGameButton = new ImageButton(new TextureRegionDrawable(loadGameTex));
        exitButton = new ImageButton(new TextureRegionDrawable(exitTex));

        // Setting positions for each button relative to the viewport
        newGameButton.setPosition(viewport.getWorldWidth() / 2 - newGameButton.getWidth() / 2, 120);
        loadGameButton.setPosition(viewport.getWorldWidth() / 2 - loadGameButton.getWidth() / 2, 60);
        exitButton.setPosition(50, viewport.getWorldHeight() - 150);

        // We add listener to start new game
        newGameButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new LevelScreen(game)); // Transition to Level Screen
                System.out.println("New Game button clicked, transitioning to LevelScreen.");
            }
        });

        // Add listener to exit the game
        exitButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                Gdx.app.exit(); // Exit application
                System.out.println("Exit button clicked, closing application.");
            }
        });
    }

    // Setup method for settings button with transition functionality
    private void setupSettingsButton() {
        settingsButton = new ImageButton(new TextureRegionDrawable(settingsButtonTex));
        settingsButton.setPosition(viewport.getWorldWidth() - settingsButton.getWidth() - 20,
            viewport.getWorldHeight() - settingsButton.getHeight() - 20);

        // Add listener to transition to settings screen
        settingsButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new SettingsScreen(game)); // Transition to SettingsScreen
                System.out.println("Settings button clicked, transitioning to SettingsScreen.");
            }
        });
    }

    @Override
    public void render(float delta) {
        clearScreen(); // Clear the screen to prevent rendering artifacts
        camera.update(); // Ensure the camera's matrices are updated

        // Render background image
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(loadingImage, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());
        batch.end();

        // Draw and update the stage (buttons and UI components)
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        // Adjust viewport to handle screen resizing
        viewport.update(width, height, true);
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        // We need to Dispose resources to avoid memory leaks
        if (batch != null) batch.dispose();
        if (loadingImage != null) loadingImage.dispose();
        if (newGameTex != null) newGameTex.dispose();
        if (loadGameTex != null) loadGameTex.dispose();
        if (exitTex != null) exitTex.dispose();
        if (settingsButtonTex != null) settingsButtonTex.dispose();
        if (stage != null) stage.dispose();
    }

    // Clears the screen with a solid color
    private void clearScreen() {
        Gdx.gl.glClearColor(0, 0, 0, 1); // Set clear color to black with full opacity
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); // Clear the buffer to apply the color
    }
}
