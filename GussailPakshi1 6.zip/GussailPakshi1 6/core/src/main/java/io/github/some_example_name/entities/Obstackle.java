package io.github.some_example_name.entities;

public class Obstackle {
}
