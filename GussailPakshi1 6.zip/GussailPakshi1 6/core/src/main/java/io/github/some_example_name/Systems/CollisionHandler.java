package io.github.some_example_name.Systems;

public class CollisionHandler {
}
