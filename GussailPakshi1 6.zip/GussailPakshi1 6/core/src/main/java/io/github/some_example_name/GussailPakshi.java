package io.github.some_example_name;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import io.github.some_example_name.UserInterface.LoadingScreen;

public class GussailPakshi extends Game {
    private SpriteBatch batch;  // Handles rendering of 2D images
    private Stage stage;        // Scene2D stage for UI components

    @Override
    public void create() {
        initializeResources();
        setInitialScreen();
    }

    private void initializeResources() {
        batch = new SpriteBatch();
        stage = new Stage();
    }

    private void setInitialScreen() {
        this.setScreen(new LoadingScreen(this));  // Load the first screen
    }

    @Override
    public void dispose() {
        if (batch != null) batch.dispose();  // Null check for safety
        if (stage != null) stage.dispose();  // Ensure resources are properly disposed
        super.dispose();  // Call to super.dispose() to handle additional cleanup
    }
}
