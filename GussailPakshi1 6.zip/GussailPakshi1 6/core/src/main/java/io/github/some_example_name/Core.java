package io.github.some_example_name;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

/** Core game application entry point implementing {@link com.badlogic.gdx.ApplicationListener}. */
public class Core extends ApplicationAdapter {
    private SpriteBatch batch; // For rendering images
    private Texture image; // Texture for displaying image

    // Initialize resources when application starts
    @Override
    public void create() {
        batch = new SpriteBatch();
        image = new Texture("libgdx.png"); // Load texture from file
    }

    // Render the game screen on every frame update
    @Override
    public void render() {
        clearScreen(); // To clear screen with background color

        batch.begin(); // Begin drawing
        batch.draw(image, 140, 210); // Draw the image at specified coordinates (here we take (140,210)
        batch.end(); // End drawing
    }

    // Creating a meethod to clear screen and separating concerns
    private void clearScreen() {
        // Slightly different color values
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
    }

    // Here we dispose of resources when application is closed
    @Override
    public void dispose() {
        if (batch != null) batch.dispose();
        if (image != null) image.dispose();
    }
}
