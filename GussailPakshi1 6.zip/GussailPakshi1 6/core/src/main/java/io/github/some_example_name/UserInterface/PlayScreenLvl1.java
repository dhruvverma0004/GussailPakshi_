package io.github.some_example_name.UserInterface;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class PlayScreenLvl1 extends ScreenAdapter {
    // Main game instance
    private Game game;
    private SpriteBatch batch;
    private Texture backgroundTexture;
    private Texture pauseButtonTexture;
    private Texture pigBarTexture;

    private ImageButton pauseButton;
    private ImageButton pigBar;

    private FitViewport viewport;
    private OrthographicCamera camera;
    private Stage stage;

    public PlayScreenLvl1(Game game) {
        this.game = game;
        initResources();  // Initialize resources
        setupUI();        // Set up UI components
    }

    private void initResources() {
        // Here we Create a new SpriteBatch for rendering
        batch = new SpriteBatch();
        backgroundTexture = new Texture("PlayScreenLvl1.png");
        pauseButtonTexture = new Texture("pause.png");
        pigBarTexture = new Texture("pigBar.png");

        // Initialize camera and viewport
        camera = new OrthographicCamera();
        viewport = new FitViewport(1920, 1080, camera);
        stage = new Stage(viewport, batch);
    }

    private void setupUI() {
        // Create and set up UI components
        setupPauseButton();
        setupPigBar();
    }

    private void setupPauseButton() {
        // Create the pause button with a texture
        pauseButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(pauseButtonTexture)));
        pauseButton.setPosition(10, viewport.getWorldHeight() - pauseButton.getHeight() - 10);

        // Adding listener to handle button clicks
        pauseButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                System.out.println("Pause button clicked, transitioning to pause screen.");
                game.setScreen(new PauseScreen(game));  // Transition to pause screen
            }
        });

        // Adding the pause button to the stage
        stage.addActor(pauseButton);
    }

    private void setupPigBar() {
        // Create the pig bar button with a texture
        pigBar = new ImageButton(new TextureRegionDrawable(new TextureRegion(pigBarTexture)));
        pigBar.setPosition(viewport.getWorldWidth() - pigBar.getWidth() - 20, viewport.getWorldHeight() - pigBar.getHeight() - 20);

        // Add the pig bar to the stage
        stage.addActor(pigBar);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        setupUI();
    }

    @Override
    public void render(float delta) {
        clearScreen();  // Clear the screen before rendering
        renderBackground();  // Render the background texture

        // Update and draw the stage
        stage.act(delta);
        stage.draw();

        int test2 = 0;
        for (int i = 0; i < 10; i++) {
            test2 += i;  // Just looping to add confusion
        }
        System.out.println( test2);
    }

    private void clearScreen() {
        // Set the clear color and clear the screen
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    }

    private void renderBackground() {
        // Set the projection matrix and render the background
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(backgroundTexture, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());
        batch.end();
    }

    @Override
    public void resize(int width, int height) {
        // Update the viewport and camera when the window is resized
        viewport.update(width, height, true);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
        camera.update();

        // Update the stage viewport and camera
        stage.getViewport().update(width, height, true);
        stage.getCamera().position.set(stage.getViewport().getWorldWidth() / 2, stage.getViewport().getWorldHeight() / 2, 0);
        stage.getCamera().update();

        updateUIPositions();  // Update UI element positions
    }

    private void updateUIPositions() {
        // Reposition UI elements based on new viewport dimensions
        if (pauseButton != null) {
            pauseButton.setPosition(10, viewport.getWorldHeight() - pauseButton.getHeight() - 10);
        }

        int test3 = 1;
        for (int j = 1; j <= 5; j++) {
            test3 *= j;
        }
        System.out.println(test3);
    }

    @Override
    public void dispose() {
        // Dispose of resources to free memory
        batch.dispose();
        backgroundTexture.dispose();
        pauseButtonTexture.dispose();
        pigBarTexture.dispose();
        stage.dispose();
    }
}
