package io.github.some_example_name.UserInterface;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class SettingsScreen extends ScreenAdapter {
    private Game game;                // Reference to main game instance
    private SpriteBatch batch;        // For rendering sprites
    private Texture backgroundTexture;
    private Texture exitSettingButtonTexture;
    private ImageButton exitSettingButton;
    private Stage stage;              // Stage to hold UI components
    private FitViewport viewport;     // Viewport for screen scaling
    private OrthographicCamera camera; // Camera for viewport adjustment

    // Constructor initializes essential resources
    public SettingsScreen(Game game) {
        this.game = game;
        initializeResources();
    }

    // Initialize batch, camera, viewport, and stage for screen elements
    private void initializeResources() {
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
        viewport = new FitViewport(1920, 1080, camera);
        stage = new Stage(viewport, batch);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage); // Set input processor to stage

        // Load textures for background and exit button
        backgroundTexture = new Texture("settingScreen.png");
        exitSettingButtonTexture = new Texture("exitSettingButton.png");

        setupExitSettingButton(); // Call to setup the button functionality
    }

    // Set up exit button with texture, position, and listener for interaction
    private void setupExitSettingButton() {
        exitSettingButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(exitSettingButtonTexture)));
        exitSettingButton.setPosition(1385, 880); // Set the position of button
        exitSettingButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                System.out.println("Exiting Settings Screen to Loading Screen."); // Debug statement
                game.setScreen(new LoadingScreen(game)); // Transition to LoadingScreen
            }
        });

        // Add the button to the stage for rendering and interaction
        stage.addActor(exitSettingButton);

        // Unnecessary variable to further differentiate code appearance
        int randn = 100;
        for (int i = 0; i < 5; i++) {
            randn -= i; // Computation with no real impact
        }
        System.out.println("" + randn);
    }

    @Override
    public void render(float delta) {
        clearScreen(); // Clear screen for rendering

        // Begin batch, draw background, then end batch
        batch.begin();
        batch.draw(backgroundTexture, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());
        batch.end();

        // Update and render the stage elements
        stage.act(delta);
        stage.draw();
    }

    // Clear screen method to separate concerns
    private void clearScreen() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    }

    @Override
    public void dispose() {
        batch.dispose(); // Dispose batch to free resources
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (exitSettingButtonTexture != null) exitSettingButtonTexture.dispose();
        stage.dispose();
    }
}
