package io.github.some_example_name.UserInterface;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class LevelScreen extends ScreenAdapter {
    private Game game;
    private SpriteBatch batch;
    private Texture backgroundImage, unlockTexture, backButtonTexture;
    private Stage stage;
    private FitViewport viewport;
    private OrthographicCamera camera;
    private ImageButton level1Button, backButton;

    // We use Constructor to initialize the game and essential variables
    public LevelScreen(Game game) {
        this.game = game;
        initialize();
    }

    // setup for camera, viewport, and stage
    private void initialize() {
        camera = new OrthographicCamera();
        viewport = new FitViewport(1920, 1080, camera);
        stage = new Stage(viewport);
        batch = new SpriteBatch();
    }

    @Override
    public void show() {
        // Here we Load textures for background and buttons
        backgroundImage = new Texture("levelScreenBackground.png");
        unlockTexture = new Texture("unlocked.png");
        backButtonTexture = new Texture("backButton.png");


        setupLevel1Button();
        setupBackButton();

        Gdx.input.setInputProcessor(stage);
    }

    // Creates and positions the button (for Level 1)
    private void setupLevel1Button() {
        level1Button = new ImageButton(new TextureRegionDrawable(new TextureRegion(unlockTexture)));
        level1Button.setSize(500, 500); // Button size
        level1Button.setPosition(-85, 670); // Button position
        level1Button.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                // Next step is to change screen to Level 1 play screen on click
                clearCurrentInputProcessor();
                game.setScreen(new PlayScreenLvl1(game));
                System.out.println("Level 1 Clicked, transitioning to play screen.");
            }
        });
        stage.addActor(level1Button); // Add button to stage
    }

    // Clears the current input processor for a clean transition
    private void clearCurrentInputProcessor() {
        Gdx.input.setInputProcessor(null); // Removing input to prevent interference
    }

    // Creates and positions the Back button with transition functionality
    private void setupBackButton() {
        backButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(backButtonTexture)));
        backButton.setSize(500, 500); // Back button size
        backButton.setPosition(-172, -168); // Back button position
        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                clearCurrentInputProcessor(); // Clear input processor before transition
                game.setScreen(new LoadingScreen(game)); // Go back to loading screen
                System.out.println("Back button clicked, transitioning to loading screen.");
            }
        });
        stage.addActor(backButton); // Add back button to stage
    }

    @Override
    public void render(float delta) {
        // Clear screen with black background
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Draw background image
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(backgroundImage, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());
        batch.end();

        // Update and draw the stage with current delta time
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        // Update viewport to adapt to screen resizing
        viewport.update(width, height, true);
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        // Dispose all resources to prevent memory leaks
        if (batch != null) batch.dispose();
        if (backgroundImage != null) backgroundImage.dispose();
        if (unlockTexture != null) unlockTexture.dispose();
        if (backButtonTexture != null) backButtonTexture.dispose();
        if (stage != null) stage.dispose();
    }
}
