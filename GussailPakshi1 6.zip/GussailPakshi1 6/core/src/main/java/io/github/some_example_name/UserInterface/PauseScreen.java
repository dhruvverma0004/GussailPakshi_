package io.github.some_example_name.UserInterface;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class PauseScreen extends ScreenAdapter {
    private Game game;
    private SpriteBatch batch;
    private Texture pauseBackground, resumeButtonTexture, lvlsButtonTexture;
    private ImageButton resumeButton, lvlsButton;
    private Stage stage;
    private FitViewport viewport;
    private OrthographicCamera camera;

    // Constructor initializes essential components
    public PauseScreen(Game game) {
        this.game = game;
        batch = new SpriteBatch();

        // Load textures for background and buttons
        pauseBackground = new Texture("pauseScreen.png");
        resumeButtonTexture = new Texture("resume.png");
        lvlsButtonTexture = new Texture("lvlsButton.png");

        // Initialize camera and viewport for scaling
        camera = new OrthographicCamera();
        viewport = new FitViewport(1920, 1080, camera);
        stage = new Stage(viewport, batch);
    }

    @Override
    public void show() {
        stage.clear(); // Clear stage to avoid duplicate actors
        setupResumeButton();
        setupLvlsButton();
        Gdx.input.setInputProcessor(stage); // Set input processor for UI interactions
    }

    // Method to set up Resume button with its functionality
    private void setupResumeButton() {
        // Create a drawable from texture region for consistent UI element sizing
        TextureRegion resumeButtonRegion = new TextureRegion(resumeButtonTexture);
        TextureRegionDrawable drawable = new TextureRegionDrawable(resumeButtonRegion);

        // Initialize ImageButton with drawable
        resumeButton = new ImageButton(drawable);
        resumeButton.setSize(100, 100); // Set size to fit UI layout
        resumeButton.setPosition(250, 500); // Position button at desired location

        // Listener to transition back to gameplay on click
        resumeButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                System.out.println("Resume button clicked, transitioning back to play screen.");
                game.setScreen(new PlayScreenLvl1(game)); // Replace with the active gameplay screen
            }
        });

        stage.addActor(resumeButton); // Add Resume button to stage
    }

    // Method to set up Levels button with its functionality
    private void setupLvlsButton() {
        TextureRegion lvlsButtonRegion = new TextureRegion(lvlsButtonTexture);
        TextureRegionDrawable drawableLvls = new TextureRegionDrawable(lvlsButtonRegion);

        // Initialize and position Levels button
        lvlsButton = new ImageButton(drawableLvls);
        lvlsButton.setSize(100, 100); // Set size for button consistency
        lvlsButton.setPosition(165, 340); // Adjust position to desired layout

        // Listener to transition to Levels screen on click
        lvlsButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                System.out.println("Levels button clicked, transitioning to level screen.");
                game.setScreen(new LevelScreen(game)); // Replace with Levels screen
            }
        });

        stage.addActor(lvlsButton); // Add Levels button to stage
    }

    @Override
    public void render(float delta) {
        // Clear the screen with a black background
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Render the pause screen background
        batch.begin();
        batch.draw(pauseBackground, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());
        batch.end();

        // Draw stage elements (buttons and UI components)
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void dispose() {
        // Dispose resources to prevent memory leaks
        if (batch != null) batch.dispose();
        if (pauseBackground != null) pauseBackground.dispose();
        if (resumeButtonTexture != null) resumeButtonTexture.dispose();
        if (lvlsButtonTexture != null) lvlsButtonTexture.dispose();
        if (stage != null) stage.dispose();
    }
}
